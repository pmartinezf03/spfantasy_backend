package com.spfantasy.backend.repository;

import com.spfantasy.backend.model.Oferta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface OfertaRepository extends JpaRepository<Oferta, Long> {
    List<Oferta> findByVendedorId(Long vendedorId);
    List<Oferta> findByCompradorId(Long compradorId);
}
