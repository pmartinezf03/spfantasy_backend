package com.spfantasy.backend.controller;

import com.spfantasy.backend.model.Oferta;
import com.spfantasy.backend.service.OfertaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/api/ofertas")
public class OfertaController {

    private final OfertaService ofertaService;

    public OfertaController(OfertaService ofertaService) {
        this.ofertaService = ofertaService;
    }

    @PostMapping
    public ResponseEntity<Oferta> crearOferta(@RequestBody Oferta oferta) {
        return ResponseEntity.ok(ofertaService.crearOferta(oferta));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Oferta> obtenerOferta(@PathVariable Long id) {
        Optional<Oferta> oferta = ofertaService.obtenerOfertaPorId(id);
        return oferta.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/vendedor/{vendedorId}")
    public ResponseEntity<List<Oferta>> obtenerOfertasPorVendedor(@PathVariable Long vendedorId) {
        return ResponseEntity.ok(ofertaService.obtenerOfertasPorVendedor(vendedorId));
    }

    @GetMapping("/comprador/{compradorId}")
    public ResponseEntity<List<Oferta>> obtenerOfertasPorComprador(@PathVariable Long compradorId) {
        return ResponseEntity.ok(ofertaService.obtenerOfertasPorComprador(compradorId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Oferta> actualizarOferta(@PathVariable Long id, @RequestBody Oferta oferta) {
        oferta.setId(id);
        return ResponseEntity.ok(ofertaService.actualizarOferta(oferta));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarOferta(@PathVariable Long id) {
        ofertaService.eliminarOferta(id);
        return ResponseEntity.noContent().build();
    }

    // 🔥 Retirar Oferta (Solo el comprador puede hacerlo)
    @DeleteMapping("/{id}/retirar")
    public ResponseEntity<?> retirarOferta(@PathVariable Long id) {
        Optional<Oferta> ofertaOpt = ofertaService.obtenerOfertaPorId(id);

        if (ofertaOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Oferta no encontrada.");
        }

        Oferta oferta = ofertaOpt.get();
        ofertaService.eliminarOferta(id);

        return ResponseEntity.ok("Oferta retirada correctamente.");
    }

    // 🔥 Aceptar Oferta (Transfiere el jugador)
    @PostMapping("/aceptar/{id}")
    public ResponseEntity<?> aceptarOferta(@PathVariable Long id) {
        ofertaService.aceptarOferta(id);
        return ResponseEntity.ok("Oferta aceptada y jugador transferido.");
    }

    // 🔥 Rechazar Oferta (Elimina la oferta)
    @DeleteMapping("/rechazar/{id}")
    public ResponseEntity<?> rechazarOferta(@PathVariable Long id) {
        ofertaService.eliminarOferta(id);
        return ResponseEntity.ok("Oferta rechazada y eliminada.");
    }
}
