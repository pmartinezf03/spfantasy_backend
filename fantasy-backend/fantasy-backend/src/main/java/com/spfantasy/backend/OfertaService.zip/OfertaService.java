package com.spfantasy.backend.service;

import com.spfantasy.backend.model.Jugador;
import com.spfantasy.backend.model.Oferta;
import com.spfantasy.backend.repository.OfertaRepository;
import com.spfantasy.backend.repository.JugadorRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OfertaService {

    private final OfertaRepository ofertaRepository;
    private final JugadorRepository jugadorRepository;

    public OfertaService(OfertaRepository ofertaRepository, JugadorRepository jugadorRepository) {
        this.ofertaRepository = ofertaRepository;
        this.jugadorRepository = jugadorRepository;
    }

    public Oferta crearOferta(Oferta oferta) {
        return ofertaRepository.save(oferta);
    }

    public Optional<Oferta> obtenerOfertaPorId(Long id) {
        return ofertaRepository.findById(id);
    }

    public List<Oferta> obtenerOfertasPorVendedor(Long vendedorId) {
        return ofertaRepository.findByVendedorId(vendedorId);
    }

    public List<Oferta> obtenerOfertasPorComprador(Long compradorId) {
        return ofertaRepository.findByCompradorId(compradorId);
    }

    public Oferta actualizarOferta(Oferta oferta) {
        return ofertaRepository.save(oferta);
    }

    public void eliminarOferta(Long id) {
        ofertaRepository.deleteById(id);
    }

    // 🔥 Aceptar Oferta: Transferir jugador
    @Transactional
    public void aceptarOferta(Long id) {
        Oferta oferta = ofertaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Oferta no encontrada"));

        // Transferir la propiedad del jugador
        Jugador jugador = oferta.getJugador();
        jugador.setPropietario(oferta.getComprador());
        jugadorRepository.save(jugador);

        // Eliminar la oferta
        ofertaRepository.delete(oferta);
    }
}
