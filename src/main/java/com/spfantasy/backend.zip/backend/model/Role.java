package com.spfantasy.backend.model;

public enum Role {
    admin, vip, usuario;
}
